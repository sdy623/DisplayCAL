from comtypes.gen import _683BF642_E9CA_4124_BE43_67065B2FA653_0_1_0
globals().update(_683BF642_E9CA_4124_BE43_67065B2FA653_0_1_0.__dict__)
__name__ = 'comtypes.gen.TaskbarLib'